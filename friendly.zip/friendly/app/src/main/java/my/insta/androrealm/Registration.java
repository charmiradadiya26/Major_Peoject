package my.insta.androrealm;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;

import my.insta.androrealm.ReusableCode.ReusableCodeForAll;
import my.insta.androrealm.models.Passwords;
import my.insta.androrealm.models.Users;
import my.insta.androrealm.models.privatedetails;

public class Registration extends AppCompatActivity {

    // Views
    TextView tvLogin;
    TextInputLayout tilName, tilEmail, tilPhone, tilPassword, tilConfirmPassword;
    EditText etDob;
    RadioGroup rgGender;
    Button btnSignUp;

    // Firebase
    FirebaseAuth fAuth;
    DatabaseReference databaseReference;
    FirebaseDatabase firebaseDatabase;

    // Values
    String name, email, phone, password, confirmPassword, gender, birth;
    String userId;

    int year, month, day;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        // Bind Views
        tvLogin = findViewById(R.id.tvLogin);
        tilName = findViewById(R.id.textInputLayoutName);
        tilEmail = findViewById(R.id.textInputLayoutEmail);
        tilPhone = findViewById(R.id.textInputLayoutPhone);
        tilPassword = findViewById(R.id.textInputLayoutPassword);
        tilConfirmPassword = findViewById(R.id.textInputLayoutConfirmPassword);
        etDob = findViewById(R.id.etDob);
        rgGender = findViewById(R.id.radioGroupGender);
        btnSignUp = findViewById(R.id.btnSignUp);

        // Firebase
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();
        fAuth = FirebaseAuth.getInstance();

        // Date picker
        etDob.setOnClickListener(v -> {
            final Calendar calendar = Calendar.getInstance();
            year = calendar.get(Calendar.YEAR);
            month = calendar.get(Calendar.MONTH);
            day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    Registration.this,
                    (DatePicker view, int y, int m, int d) -> etDob.setText(d + "/" + (m + 1) + "/" + y),
                    year, month, day
            );
            datePickerDialog.show();
        });

        // Already have account
        tvLogin.setOnClickListener(v -> {
            Intent intent = new Intent(Registration.this, Login.class);
            startActivity(intent);
            finish();
        });

        // Register
        btnSignUp.setOnClickListener(v -> {
            name = tilName.getEditText().getText().toString().trim();
            email = tilEmail.getEditText().getText().toString().trim();
            phone = tilPhone.getEditText().getText().toString().trim();
            password = tilPassword.getEditText().getText().toString().trim();
            confirmPassword = tilConfirmPassword.getEditText().getText().toString().trim();
            birth = etDob.getText().toString().trim();

            int selectedId = rgGender.getCheckedRadioButtonId();
            if (selectedId != -1) {
                RadioButton rb = findViewById(selectedId);
                gender = rb.getText().toString();
            } else {
                gender = "";
            }

            if (isValid()) {
                ProgressDialog mDialog = new ProgressDialog(Registration.this);
                mDialog.setCancelable(false);
                mDialog.setMessage("Registering, please wait...");
                mDialog.show();

                fAuth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener(task -> {
                            if (task.isSuccessful()) {
                                userId = fAuth.getCurrentUser().getUid();

                                // Store in DB
                                addUsers(name, userId);
                                addPrivateDetails(userId, email, gender, birth, phone);
                                addPasswords(password);

                                mDialog.dismiss();

                                fAuth.getCurrentUser().sendEmailVerification()
                                        .addOnCompleteListener(task1 -> {
                                            if (task1.isSuccessful()) {
                                                AlertDialog.Builder builder = new AlertDialog.Builder(Registration.this);
                                                builder.setMessage("Registered Successfully, Please Verify your Email");
                                                builder.setCancelable(false);
                                                builder.setPositiveButton("OK", (dialog, which) -> {
                                                    dialog.dismiss();
                                                    startActivity(new Intent(Registration.this, Login.class));
                                                });
                                                builder.create().show();
                                            } else {
                                                mDialog.dismiss();
                                                ReusableCodeForAll.ShowAlert(Registration.this, "Error", task1.getException().getMessage());
                                            }
                                        });
                            } else {
                                mDialog.dismiss();
                                ReusableCodeForAll.ShowAlert(Registration.this, "Error", task.getException().getMessage());
                            }
                        });
            }
        });
    }

    // Validation
    private boolean isValid() {
        boolean valid = true;

        if (TextUtils.isEmpty(name)) {
            tilName.setError("Name is required");
            valid = false;
        } else tilName.setError(null);

        if (TextUtils.isEmpty(email)) {
            tilEmail.setError("Email is required");
            valid = false;
        } else tilEmail.setError(null);

        if (TextUtils.isEmpty(phone) || phone.length() < 10) {
            tilPhone.setError("Valid phone number required");
            valid = false;
        } else tilPhone.setError(null);

        if (TextUtils.isEmpty(password) || password.length() < 6) {
            tilPassword.setError("Password must be at least 6 characters");
            valid = false;
        } else tilPassword.setError(null);

        if (!password.equals(confirmPassword)) {
            tilConfirmPassword.setError("Passwords do not match");
            valid = false;
        } else tilConfirmPassword.setError(null);

        if (TextUtils.isEmpty(gender)) {
            ReusableCodeForAll.ShowAlert(this, "Error", "Please select gender");
            valid = false;
        }

        if (TextUtils.isEmpty(birth)) {
            etDob.setError("Birth date is required");
            valid = false;
        } else etDob.setError(null);

        return valid;
    }

    // Firebase DB
    public void addUsers(String fullName, String userId) {
        Users user = new Users(
                "", // description
                "0", // followers
                "0", // following
                fullName,
                "0", // posts
                "https://firebasestorage.googleapis.com/v0/b/instagram-clone-291e7.appspot.com/o/generalProfilePhoto%2Fdefualt_insta_pic.png?alt=media&token=e9834979-a141-48fd-87b6-a2074e7dbc9b",
                fullName, // username same as name
                "", // website
                userId
        );
        databaseReference.child("Users").child(userId).setValue(user);
    }

    public void addPrivateDetails(String user_id, String email, String gender, String birthdate, String phoneNumber) {
        privatedetails details = new privatedetails(user_id, email, gender, birthdate, phoneNumber);
        databaseReference.child("Privatedetails").child(user_id).setValue(details);
    }

    public void addPasswords(String passwords) {
        Passwords pass = new Passwords(passwords);
        databaseReference.child("Passwords").child(userId).setValue(pass);
    }
}
