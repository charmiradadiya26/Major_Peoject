package my.insta.androrealm.Post;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.UUID;

import my.insta.androrealm.Home;
import my.insta.androrealm.R;
import my.insta.androrealm.Utils.methods;

public class PostActivity extends AppCompatActivity {

    ImageView postImage;
    EditText captionInput, tagsInput, locationInput;
    Button cancelBtn, uploadBtn;

    DatabaseReference databaseReference, data;
    StorageReference storageReference, ref;
    methods method;
    int count = 0;
    int PICK_IMAGE_REQUEST = 1;

    Uri imageUri;
    String postId, userId, postCount, caption, tags, location;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);

        // Bind views
        postImage = findViewById(R.id.postImage);
        captionInput = findViewById(R.id.captionInput);
        tagsInput = findViewById(R.id.tagsInput);
        locationInput = findViewById(R.id.locationInput);
        cancelBtn = findViewById(R.id.cancelBtn);
        uploadBtn = findViewById(R.id.uploadBtn);

        storageReference = FirebaseStorage.getInstance().getReference();
        databaseReference = FirebaseDatabase.getInstance().getReference();
        method = new methods();
        count = getCount();

        // Cancel button
        cancelBtn.setOnClickListener(v -> {
            startActivity(new Intent(PostActivity.this, Home.class));
            finish();
        });

        // Upload button
        uploadBtn.setOnClickListener(v -> uploadImage());

        // Open gallery when image clicked
        postImage.setOnClickListener(v -> openFileChooser());
    }

    private void openFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();
            postImage.setImageURI(imageUri);
        }
    }

    private void uploadImage() {
        if (imageUri != null) {
            final ProgressDialog progressDialog = new ProgressDialog(PostActivity.this);
            progressDialog.setTitle("Uploading...");
            progressDialog.show();

            caption = captionInput.getText().toString().trim();
            tags = tagsInput.getText().toString().trim();
            location = locationInput.getText().toString().trim();

            postId = UUID.randomUUID().toString();
            userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
            ref = storageReference.child("photos/users/" + userId + "/photo" + (count + 1));

            ref.putFile(imageUri)
                    .addOnSuccessListener(taskSnapshot -> ref.getDownloadUrl().addOnSuccessListener(uri -> {
                        increasePostCount(count);
                        addPost(caption, getTimestamp(), String.valueOf(uri), postId, userId, tags, location);
                        progressDialog.dismiss();
                        Toast.makeText(PostActivity.this, "Posted successfully", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(PostActivity.this, Home.class));
                        finish();
                    }))
                    .addOnFailureListener(e -> {
                        progressDialog.dismiss();
                        Toast.makeText(PostActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    })
                    .addOnProgressListener(taskSnapshot -> {
                        double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                        progressDialog.setMessage("Uploaded " + (int) progress + "%");
                        progressDialog.setCanceledOnTouchOutside(false);
                    });
        } else {
            Toast.makeText(this, "Please select an image first", Toast.LENGTH_SHORT).show();
        }
    }

    public void addPost(String caption, String date_Created, String image_Path, String photo_id,
                        String user_id, String tags, String location) {
        HashMap<String, String> map = new HashMap<>();
        map.put("caption", caption);
        map.put("date_Created", date_Created);
        map.put("image_Path", image_Path);
        map.put("photo_id", photo_id);
        map.put("tags", tags);
        map.put("location", location);
        map.put("user_id", user_id);
        databaseReference.child("User_Photo").child(user_id).child(photo_id).setValue(map);
        databaseReference.child("Photo").child(photo_id).setValue(map);
    }

    public void increasePostCount(final int count) {
        data = FirebaseDatabase.getInstance().getReference("Users").child(userId);
        data.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                postCount = Integer.toString(count + 1);
                data.child("posts").setValue(postCount);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private String getTimestamp() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return sdf.format(new Date());
    }

    public int getCount() {
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                count = method.getImagecount(snapshot);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
        return count;
    }

    @Override
    public void onBackPressed() {
        finish();
    }
}
