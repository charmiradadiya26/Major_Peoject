package my.insta.androrealm;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;

import my.insta.androrealm.R;

public class PrivacyPolicyActivity extends AppCompatActivity {

    private WebView webView;
    // Replace this with your real privacy policy URL or a local asset (file:///android_asset/privacy.html)
    private static final String PRIVACY_URL = "https://yourdomain.com/privacy";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_privacy_policy);

        webView = findViewById(R.id.webview_policy);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl(PRIVACY_URL);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
