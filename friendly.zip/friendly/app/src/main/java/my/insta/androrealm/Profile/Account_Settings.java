package my.insta.androrealm.Profile;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

import my.insta.androrealm.Login;
import my.insta.androrealm.R;

public class Account_Settings extends AppCompatActivity {

    TextView editProfile, changePassword, privacyPolicy, helpSupport, about, logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account__settings);

        editProfile = findViewById(R.id.edit_profile);
        changePassword = findViewById(R.id.change_password);
        privacyPolicy = findViewById(R.id.privacy_policy);
        helpSupport = findViewById(R.id.help_support);
        about = findViewById(R.id.about);
        logout = findViewById(R.id.logout);

        // Edit Profile
        editProfile.setOnClickListener(v -> {
            Intent intent = new Intent(Account_Settings.this, EditProfile.class);
            startActivity(intent);
        });

        // Change Password
        changePassword.setOnClickListener(v -> {
            FirebaseAuth auth = FirebaseAuth.getInstance();
            String email = auth.getCurrentUser().getEmail();
            auth.sendPasswordResetEmail(email)
                    .addOnSuccessListener(aVoid -> {
                        new AlertDialog.Builder(Account_Settings.this)
                                .setMessage("Password reset link sent to your email.")
                                .setPositiveButton("OK", null)
                                .show();
                    })
                    .addOnFailureListener(e -> {
                        new AlertDialog.Builder(Account_Settings.this)
                                .setMessage("Error: " + e.getMessage())
                                .setPositiveButton("OK", null)
                                .show();
                    });
        });

        // Privacy Policy
        privacyPolicy.setOnClickListener(v -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://yourdomain.com/privacy")); // Replace with your link
            startActivity(browserIntent);
        });

        // Help & Support (opens email)
        helpSupport.setOnClickListener(v -> {
            Intent email = new Intent(Intent.ACTION_SENDTO);
            email.setData(Uri.parse("mailto:support@yourapp.com"));
            email.putExtra(Intent.EXTRA_SUBJECT, "App Support Request");
            startActivity(email);
        });

        // About
        about.setOnClickListener(v -> {
            new AlertDialog.Builder(Account_Settings.this)
                    .setTitle("About This App")
                    .setMessage("Instagram Clone App\nVersion 1.0\nDeveloped by YourName")
                    .setPositiveButton("OK", null)
                    .show();
        });

        // Logout
        logout.setOnClickListener(v -> {
            new AlertDialog.Builder(Account_Settings.this)
                    .setMessage("Are you sure you want to Logout?")
                    .setCancelable(false)
                    .setPositiveButton("Yes", (dialog, id) -> {
                        FirebaseAuth.getInstance().signOut();
                        Intent intent = new Intent(Account_Settings.this, Login.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                    })
                    .setNegativeButton("No", null)
                    .show();
        });
    }
}
