package my.insta.androrealm.Stories;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.canhub.cropper.CropImage;
import com.canhub.cropper.CropImageContract;
import com.canhub.cropper.CropImageContractOptions;
import com.canhub.cropper.CropImageOptions;
import com.canhub.cropper.CropImageView;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;

import my.insta.androrealm.MainActivity;
import my.insta.androrealm.R;

public class AddStoryActivity extends AppCompatActivity {

    private static final String TAG = "AddStoryActivity";

    private Uri mImageUri;
    private ImageView previewImage;
    private EditText captionEditText;
    private StorageTask uploadTask;
    private StorageReference storageRef;

    // CropImage launcher
    private final androidx.activity.result.ActivityResultLauncher<CropImageContractOptions> cropImageLauncher =
            registerForActivityResult(new CropImageContract(), result -> {
                if (result.isSuccessful()) {
                    mImageUri = result.getUriContent();
                    previewImage.setImageURI(mImageUri);
                } else {
                    Toast.makeText(this, "Image selection failed!", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_story);

        storageRef = FirebaseStorage.getInstance().getReference("story");

        // Toolbar setup
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Edit Story");
        }
        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        // Views
        previewImage = findViewById(R.id.preview_image);
        captionEditText = findViewById(R.id.caption_edit_text);
        Button btnSave = findViewById(R.id.btn_save_story);
        FloatingActionButton btnChangeImage = findViewById(R.id.btn_change_image);

        // Open cropper at start
        openImagePicker();

        // Change image
        btnChangeImage.setOnClickListener(v -> openImagePicker());

        // Save story
        btnSave.setOnClickListener(v -> uploadImage_10());
    }

    private void openImagePicker() {
        cropImageLauncher.launch(
                new CropImageContractOptions(null, new CropImageOptions())
                        .setGuidelines(CropImageView.Guidelines.ON)
                        .setAspectRatio(1, 1)
        );
    }

    private String getFileExtension(Uri uri) {
        ContentResolver cR = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));
    }

    private void uploadImage_10() {
        if (mImageUri == null) {
            Toast.makeText(this, "No image selected", Toast.LENGTH_SHORT).show();
            return;
        }

        final ProgressDialog pd = new ProgressDialog(this);
        pd.setMessage("Posting...");
        pd.show();

        final StorageReference fileReference = storageRef.child(System.currentTimeMillis()
                + "." + getFileExtension(mImageUri));

        uploadTask = fileReference.putFile(mImageUri);
        uploadTask.continueWithTask(task -> {
            if (!task.isSuccessful()) throw task.getException();
            return fileReference.getDownloadUrl();
        }).addOnCompleteListener(task -> {
            pd.dismiss();
            if (task.isSuccessful()) {
                Uri downloadUri = (Uri)  task.getResult();
                String miUrlOk = downloadUri.toString();

                String myid = FirebaseAuth.getInstance().getCurrentUser() != null ?
                        FirebaseAuth.getInstance().getCurrentUser().getUid() : "unknown";

                DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Story")
                        .child(myid);

                String storyid = reference.push().getKey();
                long timeend = System.currentTimeMillis() + 86400000; // 24 hours

                HashMap<String, Object> hashMap = new HashMap<>();
                hashMap.put("imageurl", miUrlOk);
                hashMap.put("caption", captionEditText.getText().toString().trim());
                hashMap.put("timestart", ServerValue.TIMESTAMP);
                hashMap.put("timeend", timeend);
                hashMap.put("storyid", storyid);
                hashMap.put("userid", myid);

                reference.child(storyid).setValue(hashMap);

                Toast.makeText(AddStoryActivity.this, "Story posted!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(AddStoryActivity.this, MainActivity.class));
                finish();

            } else {
                Toast.makeText(AddStoryActivity.this, "Upload failed", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(e -> {
            pd.dismiss();
            Toast.makeText(AddStoryActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
        });
    }
}
