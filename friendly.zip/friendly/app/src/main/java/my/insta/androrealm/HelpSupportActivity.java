package my.insta.androrealm;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import my.insta.androrealm.R;

public class HelpSupportActivity extends AppCompatActivity {

    EditText subjectEt, messageEt;
    Button sendBtn;
    private static final String SUPPORT_EMAIL = "support@yourapp.com";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_support);

        subjectEt = findViewById(R.id.help_subject);
        messageEt = findViewById(R.id.help_message);
        sendBtn = findViewById(R.id.btn_send_help);

        sendBtn.setOnClickListener(v -> {
            String subject = subjectEt.getText().toString().trim();
            String body = messageEt.getText().toString().trim();
            if (subject.isEmpty() || body.isEmpty()) {
                Toast.makeText(this, "Please fill subject and message", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("mailto:" + SUPPORT_EMAIL));
            intent.putExtra(Intent.EXTRA_SUBJECT, subject);
            intent.putExtra(Intent.EXTRA_TEXT, body);
            if (intent.resolveActivity(getPackageManager()) != null) startActivity(intent);
            else Toast.makeText(this, "No email app found", Toast.LENGTH_SHORT).show();
        });
    }
}
