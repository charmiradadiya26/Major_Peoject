package my.insta.androrealm.Messages.Notification;

public class MyResponse {
    public int success;
}
