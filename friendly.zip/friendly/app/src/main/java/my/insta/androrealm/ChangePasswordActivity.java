package my.insta.androrealm.Profile;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

import my.insta.androrealm.R;

public class ChangePasswordActivity extends AppCompatActivity {

    Button btnSendReset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);

        btnSendReset = findViewById(R.id.btn_send_reset);

        btnSendReset.setOnClickListener(v -> {
            FirebaseAuth auth = FirebaseAuth.getInstance();
            if (auth.getCurrentUser() == null || auth.getCurrentUser().getEmail() == null) {
                Toast.makeText(this, "No logged-in user found", Toast.LENGTH_SHORT).show();
                return;
            }
            String email = auth.getCurrentUser().getEmail();
            auth.sendPasswordResetEmail(email)
                    .addOnSuccessListener(aVoid -> Toast.makeText(ChangePasswordActivity.this,
                            "Reset link sent to " + email, Toast.LENGTH_LONG).show())
                    .addOnFailureListener(e -> Toast.makeText(ChangePasswordActivity.this,
                            "Failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
        });
    }
}
