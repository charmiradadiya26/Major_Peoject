package my.insta.androrealm.Post;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import my.insta.androrealm.Messages.MessageActivity;
import my.insta.androrealm.R;

public class PostViewerActivity extends AppCompatActivity {

    private ImageView imgSave, imgSend, imgDelete;
    private String postId, postOwnerId, currentUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_posts_viewer);

        // Get postId and postOwnerId from intent
        postId = getIntent().getStringExtra("postId");
        postOwnerId = getIntent().getStringExtra("postOwnerId");
        currentUserId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        imgSave = findViewById(R.id.img_save);
        imgSend = findViewById(R.id.img_send);
        imgDelete = findViewById(R.id.img_delete);

        // Show delete only if current user owns the post
        if (currentUserId.equals(postOwnerId)) {
            imgDelete.setVisibility(ImageView.VISIBLE);
        }

        // Save post click
        imgSave.setOnClickListener(v -> savePost());

        // Share post click
        imgSend.setOnClickListener(v -> sharePostToChat());

        // Delete post click
        imgDelete.setOnClickListener(v -> deletePost());
    }

    private void savePost() {
        if (postId == null) {
            Toast.makeText(this, "Post ID missing!", Toast.LENGTH_SHORT).show();
            return;
        }
        DatabaseReference ref = FirebaseDatabase.getInstance()
                .getReference("SavedPosts")
                .child(currentUserId);

        ref.child(postId).setValue(true)
                .addOnSuccessListener(aVoid -> Toast.makeText(this, "Post saved", Toast.LENGTH_SHORT).show())
                .addOnFailureListener(e -> Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    private void sharePostToChat() {
        if (postId == null) {
            Toast.makeText(this, "Post ID missing!", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(PostViewerActivity.this, MessageActivity.class);
        intent.putExtra("shared_post_id", postId);
        intent.putExtra("shared_post_owner_id", postOwnerId);
        startActivity(intent);
    }

    private void deletePost() {
        if (postId == null || postOwnerId == null) {
            Toast.makeText(this, "Cannot delete: Missing info", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!currentUserId.equals(postOwnerId)) {
            Toast.makeText(this, "You can only delete your own posts", Toast.LENGTH_SHORT).show();
            return;
        }

        DatabaseReference ref = FirebaseDatabase.getInstance()
                .getReference("User_Photo")
                .child(postOwnerId)
                .child(postId);

        DatabaseReference ref2 = FirebaseDatabase.getInstance()
                .getReference("Photo")
                .child(postId);

        ref.removeValue();
        ref2.removeValue()
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Post deleted", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}
